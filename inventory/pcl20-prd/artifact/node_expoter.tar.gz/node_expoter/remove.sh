#!/bin/sh

sudo service node_exporter stop
sudo rm  /usr/local/bin/node_exporter /etc/systemd/system/node_exporter.service 
sudo deluser node_exporter
sudo delgroup node_exporter
sudo systemctl daemon-reload
