#!/bin/sh

pwd
sudo pwd
sudo cp node_exporter  /usr/local/bin/node_exporter
sudo cp node_exporter.service /etc/systemd/system/ 
#sudo adduser --system node_exporter
sudo useradd -rs /bin/false node_exporter
sudo chown node_exporter:node_exporter /usr/local/bin/node_exporter
sudo systemctl daemon-reload
sudo service node_exporter start
sudo service node_exporter status
